### 扫一扫关注我们 加入QQ群（1313974）或者关注公众号获得更多技术咨询、技术交流、技术资源...<br />


## 优质课程推荐 我们也致力于技术视频的录制，希望大家学到更多的技术...<br />

[《springboot + netty + mui 仿微信全栈 高性能后台+移动客户端》](https://coding.imooc.com/class/261.html)<br />
[《SpringBoot 仿抖音短视频小程序开发 全栈式实战项目》](https://coding.imooc.com/class/217.html)<br />
[《SpringBoot 极速入门之开发常用技术整合》](https://www.imooc.com/learn/956)<br />
[《ZooKeeper分布式专题与Dubbo微服务入门》](https://coding.imooc.com/class/201.html)<br />

[《Shiro权限管理在J2EE企业级开发中的应用与实战》](http://www.itzixi.com/course/detail.shtml?courseId=170925BH9R40SAY8)<br />
[《公开课：从单体到分布式（集群）架构的演变过程》](http://www.itzixi.com/course/detail.shtml?courseId=180207HD3DCF3YA8)<br />

[《公开课：拒绝碧池！使用ngrok进行内网穿透》](http://www.itzixi.com/course/detail.shtml?courseId=1803237WYPNX3H6W)<br />
[《MUI基础入门，开发混合端移动app》](http://www.itzixi.com/course/detail.shtml?courseId=1806269F3WXP77R4)<br />

[《ssm redis 数据字典在J2EE中的多种应用与实现》](http://www.itzixi.com/course/detail.shtml?courseId=17092078Y3009WX4)<br />
[《使用新版支付宝接口实现第三方网关支付》](http://www.itzixi.com/course/detail.shtml?courseId=170818C4XS6SPG9P)<br />
[《SpringMVC 实现web端微信扫码支付(即时到账)》](http://www.itzixi.com/course/detail.shtml?courseId=1709029W0AFN7X1P)<br />
[《Linux - Java开发者所需要掌握的一门最基本的技能》](http://www.itzixi.com/course/detail.shtml?courseId=170802GTMYF0GYNC)<br />
[《LeeCX 开源后台管理系统 git+maven+ssm (不断更新)》](http://www.itzixi.com/course/detail.shtml?courseId=17091175XBRXMS14)<br />
[《插件推荐：mybatis-pagehelper + jqgrid 实现无刷新分页》](http://www.itzixi.com/course/detail.shtml?courseId=1709106XFPFRT4SW)<br />
